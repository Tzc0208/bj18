from django.utils.safestring import mark_safe


class Pagination(object):
    def __init__(self, request, queryset, page_size=10, page_param='page', plus=5):
        '''
        :param request: 请求的对象
        :param queryset: 符合条件的数据（根据这个数据给他进行分页处理）
        :param page_size: 每页显示多少条数据
        :param page_param: 在URL中传递的获取分页的参数，例如：/etty/list/?page=12
        :param plus: 显示当前页的 前或后几页（页码）
        '''

        from django.http.request import QueryDict
        import copy
        # print(request.GET)  # <QueryDict: {'page': ['1']}>
        # print(request.GET.urlencode())  # 获取url中的参数 http://127.0.0.1:8000/pretty/list/?page=1 获取到的是 page=1
        # request.GET.setlist('page', [1])  # 报错 不能修改 This QueryDict instance is immutable  不可变的  所以需要copy 深拷贝

        # 正确方式
        # query_dict = copy.deepcopy(request.GET)  # 深拷贝  拷贝原来的 <QueryDict: {'page': ['1']}>
        # # print(query_dict)
        # query_dict._mutable = True  # 把它设置为可修改的 然后修改
        # query_dict.setlist('page', [1])  # 把page的值设置为1
        # print(query_dict.urlencode())  # page=1  这样就可以修改了

        # 操作方式
        query_dict = copy.deepcopy(request.GET)
        query_dict._mutable = True
        self.query_dict = query_dict

        page = request.GET.get(page_param, "1")   # 获取当前页码  默认为1 如果没有page参数则默认为1

        # 方法一
        try:
            page = int(page)
        except Exception as e:
            page = 1

        '''
        方法二:
        Python中isdecimal()函数的作用是检查一个字符串是否仅有十进制的数字字符构成。如果是则返回True，否则返回False
        # if page.isdecimal():  # 判断是否为数字
        #     page = int(page)
        # else:
        #     page = 1
        '''

        self.page = page  # 当前页码
        self.page_size = page_size  # 每页显示的条数
        self.page_param = page_param  # 分页参数
        self.plus = plus  # 当前页码前后显示的页码数

        self.start = (page - 1) * page_size  # 每页显示10条数据  头条数据的索引
        self.end = page * page_size      # 尾条数据的索引

        self.page_queryset = queryset[self.start:self.end]   # 当前页的数据  切片 [0:10] ...

        total_count = queryset.count()  # 总条数
        total_page_count, div = divmod(total_count, page_size)  # 总页数 余数
        if div:  # 如果有余数 就加一页 如果没有余数 就不加 跳过
            total_page_count += 1
        self.total_page_count = total_page_count  # 总页数

    # 定义一个方法 用来生成页码
    def html(self):
        # 计算出显示当前页的前5页、后5页
        # 如果总页数小于等于11页  就显示所有页码
        if self.total_page_count <= 2 * self.plus + 1:  # 11页
            # 比如数据库中总页数就11页 数据库中的数据没有超过11页  就显示所有页码
            start_page = 1  # 从第一页开始  例如：1 2 3 4 5 6 7 8 9 10 11  从1开始  到11结束  一共11页
            end_page = self.total_page_count + 1  # 到最后一页结束  +1是因为range函数不包含最后一个值
        else:
            # 如果数据库中总页数 > 11页
            # 当前页 < 5页时（小极值）
            if self.page <= self.plus:
                start_page = 1
                end_page = 2 * self.plus + 1 + 1  # 从第1页开始  到第11页结束  一共11页  +1是因为range函数不包含最后一个值
            else:
                # 当前页 > 5
                # 当前页 + 5 > 总页数
                if self.page + self.plus > self.total_page_count:
                    start_page = self.total_page_count - 2 * self.plus  # 1
                    end_page = self.total_page_count + 1  # +1是因为range函数不包含最后一个值
                else:
                    start_page = self.page - self.plus  # 例如当前页是第6页 那么前5页就是第1页
                    end_page = self.page + self.plus + 1  # 例如当前页是第6页 那么后5页就是第11页

        # 页码
        page_str_list = []

        # 首页
        self.query_dict.setlist(self.page_param, [1])  # 修改page参数的值为1
        first_page = '<li><a href="?%s">首页</a></li>' % self.query_dict.urlencode()
        page_str_list.append(first_page)

        # 上一页
        self.query_dict.setlist(self.page_param, [self.page - 1])
        prev = '<li><a href="?%s">上一页</a></li>' % self.query_dict.urlencode()
        if self.page <= 1:
            self.query_dict.setlist(self.page_param, [1])
            prev = '<li><a href="?%s">上一页</a></li>' % self.query_dict.urlencode()  # 如果当前页码小于等于1  则上一页为1
        page_str_list.append(prev)

        # 页面
        for i in range(start_page, end_page):  # 加一是因为range不包含最后一个数 所有要加一
            self.query_dict.setlist(self.page_param, [i])
            if i == self.page:
                str_html = '<li class="active"><a href="?%s">%s</a></li>' % (self.query_dict.urlencode(), i)
            else:
                str_html = '<li><a href="?%s">%s</a></li>' % (self.query_dict.urlencode(), i)  # 生成页码<li><a href="?page=1">1</a></li>
            page_str_list.append(str_html)

        # 下一页
        self.query_dict.setlist(self.page_param, [self.page + 1])
        next = '<li><a href="?%s">下一页</a></li>' % self.query_dict.urlencode()
        if self.page >= self.total_page_count:
            self.query_dict.setlist(self.page_param, [self.total_page_count])
            next = '<li><a href="?%s">下一页</a></li>' % self.query_dict.urlencode()  # 如果当前页码大于等于总页数  则下一页为总页数
        page_str_list.append(next)

        # 尾页
        self.query_dict.setlist(self.page_param, [self.total_page_count])
        last_page = '<li><a href="?%s">尾页</a></li>' % self.query_dict.urlencode()
        page_str_list.append(last_page)

        # 搜索栏
        search_string = """
            <li>
                <form style="float: left;margin-left: -1px" method="get">
                    <input name="page"
                           style="position: relative;float:left;display: inline-block;width: 80px;border-radius: 0;"
                           type="text" class="form-control" placeholder="页码">
                    <button style="border-radius: 0" class="btn btn-default" type="submit">跳转</button>
                </form>
            </li>
        """

        page_str_list.append(search_string)

        # 拼接成字符串 <li><a href="?page=1">1</a></li><li><a href="?page=2">2</a></li> ...
        page_string = mark_safe("".join(page_str_list))

        return page_string
