from epidemic import models
from epidemic.utils.bootstrap import BootStrapModelForm
from django import forms
from django.core.validators import RegexValidator
from django.core.exceptions import ValidationError


class UserAddModelForm(BootStrapModelForm):
    # 自定义字段
    # 验证：方式1  通过正则表达式验证
    phone = forms.CharField(
        label='手机号',
        validators=[RegexValidator(r'^1[3|5|7|8]\d{9}$', '手机号格式错误'), ],  # 正则校验  处理简单的校验  然后通过钩子函数 处理复杂的校验
    )
    id_card = forms.CharField(
        label='身份证号',
        validators=[RegexValidator(r'^\d{17}[\d|x]$', '身份证号格式错误'), ],  # 正则校验  处理简单的校验  然后通过钩子函数 处理复杂的校验
    )

    class Meta:
        model = models.UserInfo
        fields = "__all__"  # 指定字段
        # exclude = ['temperature', "temperature_status"]  # 排除字段

    # 验证：方式2  通过钩子函数验证
    def clean_phone(self):  # clean_字段名
        txt_phone = self.cleaned_data['phone']  # 获取用户输入的手机号  通过字段名获取  也可以通过get('字段名')获取 但不建议  因为如果字段名不存在 会报错
        # 验证手机号或者身份证号是否已经存在
        exists = models.UserInfo.objects.filter(phone=txt_phone).exists()  # exists() 判断一个对象是否存在  返回True或False

        if exists:  # 如果存在 抛出异常
            raise ValidationError('手机号已经存在')
        return txt_phone  # 返回用户输入的手机号  但是必须返回  否则会报错

    def clean_id_card(self):
        txt_id_card = self.cleaned_data['id_card']  # 获取用户输入的身份证号
        # 验证身份证号是否已经存在
        exists = models.UserInfo.objects.filter(id_card=txt_id_card).exists()  # exists() 判断一个对象是否存在  返回True或False

        if exists:  # 如果存在 抛出异常
            raise ValidationError('身份证号已经存在')
        return txt_id_card  # 返回用户输入的身份证号


class UserEditModelForm(BootStrapModelForm):
    # 自定义字段
    # mobile = forms.CharField(disabled=True, label='手机号')  # 禁用字段

    phone = forms.CharField(
        label='手机号',
        validators=[RegexValidator(r'^1[3|5|7|8]\d{9}$', '手机号格式错误'), ],  # 正则校验  处理简单的校验  然后通过钩子函数 处理复杂的校验
        # disabled=True,  # 禁用字段
    )

    class Meta:
        model = models.UserInfo
        fields = "__all__"  # 指定字段
        # exclude = ['temperature', "temperature_status"]  # 排除字段

    # 通过钩子函数验证
    def clean_phone(self):  # clean_字段名
        txt_phone = self.cleaned_data['phone']  # 获取用户输入的手机号  通过字段名获取  也可以通过get('字段名')获取 但不建议  因为如果字段名不存在 会报错

        # print(self.instance.id)  # 获取当前对象的主键pk  也就是当前对象的id
        # exclude(id=self.instance.id) 排除当前对象
        exists = models.UserInfo.objects.exclude(id=self.instance.id).filter(phone=txt_phone).exists()
        # 排除当前对象id id的手机号除外 再手机号进行判断  如果存在  抛出异常  如果不存在  返回手机号
        if exists:
            raise ValidationError('手机号已存在')
        return txt_phone


# ---------------------------------设备管理---------------------------------

class DeviceModelForm(BootStrapModelForm):
    ip = forms.CharField(
        label='设备IP',
        # 正则校验  处理简单的校验  然后通过钩子函数 处理复杂的校验
        validators=[RegexValidator(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', 'IP格式错误'), ],
    )

    class Meta:
        model = models.DeviceInfo
        exclude = ["number"]


# ---------------------------------模拟数据---------------------------------

class MockDataModelForm(BootStrapModelForm):
    class Meta:
        model = models.MockData
        # fields = "__all__"
        exclude = ["temperature_status"]

    # def clean_temperature(self):
    #     # 如果体温大于37.5  则体温为异常 否则为正常
    #     temperature = self.cleaned_data['temperature']
    #     print(temperature)
    #     if temperature > 37.5:
    #         # 状态返回到列表页
    #         self.instance.temperature_status = 2  # 异常
    #         # print(self.instance.temperature_status)
    #     else:
    #         self.instance.temperature_status = 1  # 正常
    #     return temperature







