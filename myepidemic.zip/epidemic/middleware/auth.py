from django.utils.deprecation import MiddlewareMixin
from django.shortcuts import redirect, render
from django.urls import reverse


class AuthMiddleware(MiddlewareMixin):
    '''中间件的process_response方法，会在视图函数执行完毕之后，再执行'''
    def process_request(self, request):
        # 1.排除那些不需要登录就能访问的页面
        # request.path_info 获取当前用户请求的URL
        if request.path_info in ["/login/"]:
            return  # 不需要登录就能访问的页面，直接放行

        # 2.读取当前访问的用户的session信息，如果能读到，说明已登陆过，就可以继续向后走。
        info_dict = request.session.get("info")
        # print(info_dict)  # 例如: {'id': 1, 'name': 'admin'}
        if info_dict:  # 如果有值，说明已登录过，就可以继续向后走。
            return  # 返回None 如果用户已登录，就继续向后走

        # 3.没有登录过，重新回到登录页面
        # return redirect(reverse("business:login"))  # 重定向到登录页面
        return redirect("/login/")
