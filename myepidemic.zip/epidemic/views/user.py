from django.shortcuts import render, redirect
from epidemic import models
from django.urls import reverse
from epidemic.utils.form import UserAddModelForm, UserEditModelForm
from epidemic.utils.pagination import Pagination  # 导入分页类  用于分页 自定义组件


def user_list(request):
    '''人员列表'''
    # **data_dict 相当于全部数据
    data_dict = {}
    # 查询姓名查询
    search_name = request.GET.get('name', "")
    if search_name:
        data_dict['name__contains'] = search_name  # 模糊查询

    # 通过手机号查询
    search_phone = request.GET.get('phone', "")
    if search_phone:
        data_dict['phone__contains'] = search_phone

    queryset = models.UserInfo.objects.filter(**data_dict)  # **data_dict 相当于全部数据
    page_object = Pagination(request, queryset)  # 实例化分页类  传入请求对象  传入数据对象

    context = {
        "search_name": search_name,  # 姓名查询
        "search_phone": search_phone,  # 手机号查询

        "queryset": page_object.page_queryset,  # 分完页的数据
        "page_string": page_object.html()  # 页码
    }

    return render(request, 'user_list.html', context)


def user_add(request):
    '''添加人员'''
    if request.method == "GET":
        form = UserAddModelForm()
        return render(request, 'user_add.html', {'form': form})

    form = UserAddModelForm(data=request.POST, files=request.FILES)
    if form.is_valid():
        form.save()
        return redirect(reverse('epidemic:user_list'))
    return render(request, 'user_add.html', {'form': form})


def user_edit(request, eid):
    '''修改人员'''
    if request.method == "GET":
        row_object = models.UserInfo.objects.get(id=eid)
        form = UserEditModelForm(instance=row_object)
        return render(request, 'user_edit.html', {'form': form})

    row_object = models.UserInfo.objects.filter(id=eid).first()
    form = UserEditModelForm(data=request.POST, instance=row_object, files=request.FILES)
    if form.is_valid():
        form.save()
        return redirect(reverse('epidemic:user_list'))
    return render(request, 'user_edit.html', {'form': form})


def user_delete(request, did):
    '''删除人员'''
    models.UserInfo.objects.filter(id=did).delete()
    return redirect(reverse('epidemic:user_list'))
