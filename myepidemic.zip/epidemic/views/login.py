from django.views import View
from django.shortcuts import render, redirect
from django.urls import reverse
from django.contrib.auth import authenticate, login, logout


class LoginView(View):
    '''登录'''
    def get(self, request):
        '''显示登录页面'''
        # 使用模板
        return render(request, 'login.html')

    def post(self, request):
        '''登录校验'''
        # user = request.user  # 获取当前登录用户  # AnonymousUser
        # print(user)  # <User: admin>

        # 接收数据
        username = request.POST.get('username')
        password = request.POST.get('password')

        # 校验数据
        if not all([username, password]):
            return render(request, 'login.html', {'errmsg': '数据不完整'})

        # 业务处理:登录校验
        user = authenticate(username=username, password=password)
        if user is not None:
            # 用户名密码正确
            if user.is_active:
                # 用户已激活
                # 记录用户的登录状态
                login(request, user)
                request.session['info'] = {"id": user.id, 'username': username}  # 将用户信息保存到session中
                request.session.set_expiry(60 * 60 * 24 * 7)  # 设置session的过期时间

                # 获取登录后所要跳转的地址
                # 默认跳转到首页
                next_url = request.GET.get('next', reverse('epidemic:user_list'))
                # 跳转到首页
                response = redirect(next_url)

                # 返回response
                return response  # 跳转到首页

            else:
                # 用户未激活
                return render(request, 'login.html', {'errmsg': '账户未激活'})
        else:
            # 用户名或密码错误
            return render(request, 'login.html', {'errmsg': '用户名或密码错误'})


class LogoutView(View):
    '''退出登录'''
    def get(self, request):
        '''退出登录'''
        # 清除用户的session信息
        logout(request)

        # 跳转到登录页
        return redirect(reverse('epidemic:login'))
