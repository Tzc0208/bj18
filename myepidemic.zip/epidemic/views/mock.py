from django.shortcuts import render, redirect
from epidemic import models
from django.urls import reverse
from epidemic.utils.form import MockDataModelForm
from epidemic.utils.pagination import Pagination  # 导入分页类  用于分页 自定义组件
from openpyxl import load_workbook  # 导入读取excel的模块


def mock_list(request):
    '''模拟数据列表'''
    # **data_dict 相当于全部数据
    data_dict = {}
    status_name = request.GET.get('status_name', "")
    select_status = request.GET.get('select_status', "")
    status = request.GET.get('status', "")
    if select_status:
        data_dict['temperature_status'] = select_status
    if status_name:
        data_dict['user__name__contains'] = status_name
    if status:
        data_dict['status'] = status
    queryset = models.MockData.objects.filter(**data_dict).order_by("-time")  # **data_dict 相当于全部数据
    page_object = Pagination(request, queryset)  # 实例化分页类  传入请求对象  传入数据对象

    context = {
        "status_name": status_name,  # 姓名查询
        'select_status': select_status,  # 状态查询
        'status': status,  # 出入状态查询
        "queryset": page_object.page_queryset,  # 分完页的数据
        "page_string": page_object.html()  # 页码
    }

    return render(request, 'mock_list.html', context)


def mock_add(request):
    '''模拟数据添加'''
    if request.method == "GET":
        form = MockDataModelForm()
        return render(request, 'mock_add.html', {'form': form})

    form = MockDataModelForm(data=request.POST)
    if form.is_valid():
        temperature = form.cleaned_data.get('temperature')
        if temperature > 37.5:
            form.instance.temperature_status = 2
            # print(form.instance.temperature_status)  # 2 异常
        else:
            form.instance.temperature_status = 1
        form.save()
        return redirect(reverse('epidemic:mock_list'))

    return render(request, 'mock_add.html', {'form': form})


def mock_delete(request, did):
    '''模拟数据删除'''
    models.MockData.objects.filter(id=did).delete()
    return redirect(reverse('epidemic:mock_list'))
