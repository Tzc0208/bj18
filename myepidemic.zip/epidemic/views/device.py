from django.shortcuts import render, redirect
from epidemic import models
from django.urls import reverse
from epidemic.utils.form import DeviceModelForm
from django import forms
import random
from django.http import JsonResponse
from datetime import datetime
from epidemic.utils.pagination import Pagination  # 导入分页类  用于分页 自定义组件
from django.views.decorators.csrf import csrf_exempt


def device_list(request):
    '''设备列表'''
    form = DeviceModelForm()

    data_dict = {}
    search_data = request.GET.get('q', "")  # 获取搜索框的值 默认为空
    if search_data:
        data_dict['name__contains'] = search_data  # 模糊查询  例如：data_dict = {'mobile__contains': '123'}

    queryset = models.DeviceInfo.objects.filter(**data_dict).order_by("id")  # 获取所有数据  并且按照level降序排列
    page_object = Pagination(request, queryset)  # 实例化分页类  传入请求对象  传入数据对象

    context = {
        "form": form,
        "search_data": search_data,  # 搜索框的值

        "queryset": page_object.page_queryset,  # 分完页的数据
        "page_string": page_object.html()  # 页码
    }

    return render(request, 'device_list.html', context)


@csrf_exempt
def device_add(request):
    '''新建设备 (Ajax请求)'''
    form = DeviceModelForm(data=request.POST)
    if form.is_valid():
        # 设备编号：额外增加一些不是用户输入的值（自己计算出来） 动态生成
        form.instance.number = datetime.now().strftime("%Y%m%d%H%M%S") + str(random.randint(10, 99))
        # 保存到数据库中
        form.save()
        return JsonResponse({'res': 0})  # 验证成功
    return JsonResponse({'res': 1, 'error': form.errors})  # 验证失败


def device_delete(request):
    '''删除设备'''
    did = request.GET.get('did')
    exists = models.DeviceInfo.objects.filter(id=did).exists()
    if not exists:
        return JsonResponse({'res': 0, 'error': '删除失败, 数据不存在'})  # 验证失败
    models.DeviceInfo.objects.filter(id=did).delete()
    return JsonResponse({"res": 1})  # 删除成功


@csrf_exempt  # 防止跨站请求伪造
def device_edit(request):
    '''编辑订单'''
    uid = request.GET.get("uid")
    row_object = models.DeviceInfo.objects.filter(id=uid).first()
    if not row_object:
        return JsonResponse({"status": False, 'tips': "数据不存在，请刷新重试。"})

    form = DeviceModelForm(data=request.POST, instance=row_object)
    if form.is_valid():
        form.save()
        return JsonResponse({"status": True})

    return JsonResponse({"status": False, 'error': form.errors})


def device_detail(request):
    uid = request.GET.get("uid")
    row_dict = models.DeviceInfo.objects.filter(id=uid).values("name", "number", "point", "ip", "status").first()
    if not row_dict:
        return JsonResponse({"status": False, 'error': "数据不存在"})

    # 从数据库中获取到一个对象 row_object
    result = {
        "status": True,
        "data": row_dict
    }
    # print(result)  # {'status': True, 'data': {'title': '哈哈哈', 'price': 200, 'status': 2}}
    return JsonResponse(result)





