from django.shortcuts import render
from django.http import JsonResponse
from epidemic import models
import datetime


def chart_list(request):
    '''数据统计页面'''
    return render(request, 'chart_list.html')


def chart_line(request):
    '''构造折线图的数据'''
    normal_count = 0  # 正常人数
    abnormal_count = 0  # 异常
    normal_list = []
    abnormal_list = []
    x_axis = []  # x轴

    # 根据MockData 表中的数据构造折线图的数据
    # 1. 获取所有的数据
    all_data = models.MockData.objects.all()
    # 2. 遍历所有的数据
    for data in all_data:
        # 3. 判断是否异常
        if data.temperature_status == 1:
            normal_count += 1
        else:
            abnormal_count += 1
        # 4. 记录每天的异常和正常人数
        normal_list.append(normal_count)
        abnormal_list.append(abnormal_count)
        # 5. 记录x轴
        x_axis.append(data.time.strftime('%Y-%m-%d'))

    # 6. 构造返回的数据
    legends = ["正常人数", "异常人数"]
    series_list = [
        {
            "name": '正常人数',
            "type": 'line',
            "data": normal_list
        },
        {
            "name": '异常人数',
            "type": 'line',
            "data": abnormal_list
        }
    ]
    result = {
        "status": True,
        "data": {
            'legends': legends,
            'series_list': series_list,
            'x_axis': x_axis,
        }
    }
    return JsonResponse(result)


def chart_pie(request):
    '''构造饼图的数据'''
    # 1. 获取所有的数据
    man_count = 0   # 男性人数
    girl_count = 0   # 女性人数
    queryset = models.UserInfo.objects.all()
    # 2. 遍历所有的数据
    for data in queryset:
        # 3. 判断性别
        if data.gender == 1:
            man_count += 1
        else:
            girl_count += 1

    # 4. 构造返回的数据
    db_data_list = [
        {"value": man_count, "name": '男'},
        {"value": girl_count, "name": '女'},
    ]

    result = {
        "status": True,
        "data": db_data_list
    }
    return JsonResponse(result)

















