from django.urls import path, re_path
from epidemic.views import user, device, mock, chart
from django.views.static import serve
from django.conf import settings
from epidemic.views.login import LoginView, LogoutView

app_name = 'epidemic'

urlpatterns = [
    re_path(r'^media/(?P<path>.*)$', serve, {'document_root': settings.MEDIA_ROOT}, name='media'),  # 配置上传文件的访问处理函数

    # 人员管理
    path('user/list/', user.user_list, name='user_list'),   # 人员列表
    path('user/add/', user.user_add, name='user_add'),  # 人员添加
    path('user/<int:eid>/edit/', user.user_edit, name='user_edit'),  # 人员编辑
    path('user/<int:did>/delete/', user.user_delete, name='user_delete'),  # 人员删除

    # 设备管理
    path('device/list/', device.device_list, name='device_list'),   # 设备列表
    path('device/add/', device.device_add, name='device_add'),  # 设备添加
    path('device/delete/', device.device_delete, name='device_delete'),  # 设备删除
    path('device/edit/', device.device_edit, name='device_edit'),  # 设备编辑
    path('device/detail/', device.device_detail, name='device_detail'),  # 设备修改

    # 模拟数据
    path('mock/list/', mock.mock_list, name='mock_list'),  # 模拟数据列表
    path('mock/add/', mock.mock_add, name='mock_add'),  # 模拟数据添加
    path('mock/<int:did>/delete/', mock.mock_delete, name='mock_delete'),  # 模拟数据删除

    # 数据统计
    path('chart/list/', chart.chart_list, name='chart_list'),  # 数据统计列表
    path('chart/line/', chart.chart_line, name='chart_line'),  # 折线图
    path('chart/pie/', chart.chart_pie, name='chart_pie'),  # 饼状图

    # 登录页面
    path('login/', LoginView.as_view(), name='login'),  # 登录
    path('logout/', LogoutView.as_view(), name='logout'),  # 退出
]
