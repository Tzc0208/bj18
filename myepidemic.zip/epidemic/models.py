from django.db import models
from django.contrib.auth.models import AbstractUser  # 导入django自带的用户模型类 作用：继承django自带的用户模型类，扩展用户模型类

# Create your models here.


class User(AbstractUser):
    '''用户模型类'''

    class Meta:
        db_table = 'df_user'
        verbose_name = '用户'
        verbose_name_plural = verbose_name


class UserInfo(models.Model):
    '''人员信息'''
    # 姓名
    name = models.CharField(verbose_name='姓名', max_length=16)
    # 性别
    gender_choices = (
        (1, '男'),
        (2, '女'),
    )
    gender = models.SmallIntegerField(verbose_name='性别', choices=gender_choices)
    # 手机号
    phone = models.CharField(verbose_name='手机号', max_length=11)
    # 身份证号
    id_card = models.CharField(verbose_name='身份证号', max_length=18)
    # # 体温
    # temperature = models.DecimalField(verbose_name='体温', max_digits=3, decimal_places=1)
    # # 体温状态
    # temperature_status_choices = (
    #     (1, '正常'),
    #     (2, '异常'),
    # )
    # temperature_status = models.SmallIntegerField(verbose_name='体温状态', choices=temperature_status_choices)
    # 住址
    address = models.CharField(verbose_name='住址', max_length=32)
    # 上传图片
    pic = models.FileField(verbose_name='上传图片', upload_to='pic')

    class Meta:
        db_table = 'df_userinfo'
        verbose_name = '人员信息'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.name


# 设备信息
class DeviceInfo(models.Model):
    # 设备名称
    name = models.CharField(verbose_name='设备名称', max_length=16)
    # 设备编号
    number = models.CharField(verbose_name='设备编号', max_length=16)
    # 设备点位
    point = models.CharField(verbose_name='设备点位', max_length=16)
    # 设备IP
    ip = models.CharField(verbose_name='设备IP', max_length=16)
    # 设备状态
    status_choices = (
        (1, '正常'),
        (2, '异常'),
    )
    status = models.SmallIntegerField(verbose_name='设备状态', choices=status_choices)

    class Meta:
        db_table = 'df_deviceInfo'
        verbose_name = '设备信息'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.name


# 模拟数据
class MockData(models.Model):
    # 人员信息
    user = models.ForeignKey(UserInfo, verbose_name='人员信息', on_delete=models.CASCADE)
    # 设备信息
    device = models.ForeignKey(DeviceInfo, verbose_name='设备信息', on_delete=models.CASCADE)
    # 体温
    temperature = models.DecimalField(verbose_name='体温', max_digits=3, decimal_places=1)
    # 体温状态
    temperature_status_choices = (
        (1, '正常'),
        (2, '异常'),
    )
    temperature_status = models.SmallIntegerField(verbose_name='体温状态', choices=temperature_status_choices)
    # 出入时间
    time = models.DateTimeField(verbose_name='出入时间', auto_now_add=True)
    # 出入状态
    status_choices = (
        (1, '出'),
        (2, '入'),
    )
    status = models.SmallIntegerField(verbose_name='出入状态', choices=status_choices, default=1)

    class Meta:
        db_table = 'df_mockData'
        verbose_name = '模拟数据'
        verbose_name_plural = verbose_name
