from django.contrib import admin
from epidemic.models import UserInfo, DeviceInfo, MockData
# Register your models here.

admin.site.register(UserInfo)
admin.site.register(DeviceInfo)
admin.site.register(MockData)
